import asyncio
import json
import time
from pathlib import Path
from typing import Dict, List, Optional
import pandas as pd
import numpy as np
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from ai_engine import PredictiveMaintenanceEngine, FEATURE_COLS

app = FastAPI(title="Predictive Maintenance API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── State ──────────────────────────────────────────────────────────────────────
CSV_PATH = Path(__file__).parent / "machine_data_log.csv"
df_global: Optional[pd.DataFrame] = None
engines: Dict[str, PredictiveMaintenanceEngine] = {}
stream_indices: Dict[str, int] = {}
latest_readings: Dict[str, dict] = {}
history_store: Dict[str, List[dict]] = {}

MACHINES = [
    {"id": "M001", "name": "Compressor A", "type": "compressor", "x": 15, "y": 20},
    {"id": "M002", "name": "Motor Drive B", "type": "motor",      "x": 45, "y": 20},
    {"id": "M003", "name": "Pump Unit C",   "type": "pump",       "x": 75, "y": 20},
    {"id": "M004", "name": "Conveyor D",    "type": "conveyor",   "x": 15, "y": 65},
    {"id": "M005", "name": "Robot Arm E",   "type": "robot",      "x": 45, "y": 65},
    {"id": "M006", "name": "Turbine F",     "type": "turbine",    "x": 75, "y": 65},
]

# ── Startup ────────────────────────────────────────────────────────────────────
@app.on_event("startup")
async def startup():
    global df_global
    if not CSV_PATH.exists():
        raise RuntimeError(f"CSV not found at {CSV_PATH}")
    
    df_global = pd.read_csv(CSV_PATH, parse_dates=['Timestamp'])
    print(f"[API] Loaded {len(df_global)} rows from CSV")
    
    # Each machine gets its own engine + stream offset (staggered for variety)
    offsets = [0, 200, 400, 600, 800, 1000]
    for i, m in enumerate(MACHINES):
        mid = m["id"]
        eng = PredictiveMaintenanceEngine()
        eng.train(df_global)
        engines[mid] = eng
        stream_indices[mid] = offsets[i]
        history_store[mid] = []
        latest_readings[mid] = {}
    
    print("[API] All engines trained. Starting background streamer...")
    asyncio.create_task(background_streamer())

# ── Background data streamer ───────────────────────────────────────────────────
async def background_streamer():
    """Advance each machine's stream pointer every 3 seconds."""
    while True:
        for m in MACHINES:
            mid = m["id"]
            idx = stream_indices[mid]
            row = df_global.iloc[idx % len(df_global)]
            
            prediction = engines[mid].predict(row)
            
            reading = {
                "timestamp": row["Timestamp"].isoformat(),
                "machine_id": mid,
                **{col: round(float(row[col]), 3) for col in FEATURE_COLS},
                **prediction,
            }
            latest_readings[mid] = reading
            history_store[mid].append(reading)
            
            # Keep last 200 historical points per machine
            if len(history_store[mid]) > 200:
                history_store[mid] = history_store[mid][-200:]
            
            stream_indices[mid] += 1
        
        await asyncio.sleep(3)

# ── Endpoints ──────────────────────────────────────────────────────────────────
@app.get("/machines")
def get_machines():
    return MACHINES

@app.get("/machines/{machine_id}/status")
def get_machine_status(machine_id: str):
    if machine_id not in latest_readings or not latest_readings[machine_id]:
        raise HTTPException(404, "No data yet")
    return latest_readings[machine_id]

@app.get("/machines/all/status")
def get_all_status():
    return {mid: latest_readings.get(mid, {}) for m in MACHINES for mid in [m["id"]]}

@app.get("/machines/{machine_id}/history")
def get_machine_history(machine_id: str, limit: int = 100):
    if machine_id not in history_store:
        raise HTTPException(404, "Machine not found")
    data = history_store[machine_id][-limit:]
    return data

@app.get("/factory/overview")
def factory_overview():
    summary = []
    for m in MACHINES:
        mid = m["id"]
        r = latest_readings.get(mid, {})
        summary.append({
            **m,
            "health_score": r.get("health_score", 100),
            "status": r.get("status", "HEALTHY"),
            "failure_probability": r.get("failure_probability", 0),
            "rul_hours": r.get("rul_hours", 9999),
        })
    return summary

@app.get("/health")
def health_check():
    return {"status": "ok", "machines": len(MACHINES)}
