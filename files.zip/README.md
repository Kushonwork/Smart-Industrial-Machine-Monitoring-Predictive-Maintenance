# NEXUS FACTORY OS — Industrial Predictive Maintenance System

Full-stack Industry 4.0 dashboard with AI anomaly detection, real-time telemetry streaming, and interactive factory floor visualization.

---

## QUICK START

### 1. Backend Setup

```bash
cd backend

# Install Python deps
pip install -r requirements.txt

# Generate sample dataset (if machine_data_log.csv not present)
python generate_data.py

# Start FastAPI server (port 8000)
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

### 2. Frontend Setup

```bash
cd frontend

# Install deps
npm install

# Start React dev server (port 3000)
npm start
```

Open: http://localhost:3000

---

## ARCHITECTURE

```
predictive-maintenance/
├── backend/
│   ├── main.py              # FastAPI app + REST endpoints
│   ├── ai_engine.py         # Isolation Forest model + RUL estimation
│   ├── generate_data.py     # Synthetic CSV generator
│   ├── machine_data_log.csv # Telemetry dataset (2000 rows)
│   └── requirements.txt
└── frontend/
    ├── src/
    │   ├── App.jsx           # Main dashboard (floor plan + side panel)
    │   └── index.js
    └── public/index.html
```

---

## API ENDPOINTS

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/machines` | All machine configs (id, name, type, position) |
| GET | `/machines/all/status` | Live AI metrics for all machines |
| GET | `/machines/{id}/status` | Single machine live reading |
| GET | `/machines/{id}/history?limit=100` | Historical telemetry |
| GET | `/factory/overview` | Floor plan overlay data |
| GET | `/health` | API health check |

---

## AI ENGINE

**Model:** Isolation Forest (sklearn)  
**Training:** First 70% of CSV rows (healthy baseline)  
**Features:** MotorTemp, AmbientTemp, Humidity, Accel X/Y/Z, VibMagnitude, DominantFreq

**Outputs per reading:**
- `health_score` (0–100): normalized anomaly score
- `failure_probability` (%): sigmoid of health score
- `rul_hours`: linear regression on last 20 readings → steps to critical threshold
- `status`: HEALTHY / WARNING / CRITICAL

---

## FRONTEND FEATURES

- **2D Factory Floor Plan** — 6 machine nodes with real-time color coding
- **Hover Tooltips** — quick status + health score
- **Click → Side Panel** — full AI predictions + live telemetry params
- **Historical Charts** — switchable: Health / Temp / Vibration / Frequency (Recharts)
- **Header KPIs** — avg health, online count, critical alert count, sys time
- **Dark Theme** — slate bg, neon cyan accents, warning yellows, alert reds

---

## ENV VARS

```bash
# frontend/.env
REACT_APP_API_URL=http://localhost:8000
```

When backend is unavailable, the frontend automatically falls back to local simulation mode.
